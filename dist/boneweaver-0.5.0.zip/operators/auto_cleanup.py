"""Blender operator adapters for automatic cleanup."""

import bpy

from ..controllers.auto_cleanup import AutoCleanupController


class BONEWEAVER_OT_auto_cleanup(bpy.types.Operator):
    bl_idname = "boneweaver.auto_cleanup"
    bl_label = "全自动整理骨架"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        return AutoCleanupController.can_run(context)

    def execute(self, context):
        success = AutoCleanupController.run(context)
        self.report({"INFO"} if success else {"WARNING"}, context.window_manager.boneweaver_runtime.quick_summary)
        return {"FINISHED"} if success else {"CANCELLED"}


class BONEWEAVER_OT_restore_auto_cleanup(bpy.types.Operator):
    bl_idname = "boneweaver.restore_auto_cleanup"
    bl_label = "恢复整理前状态"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        return AutoCleanupController.can_restore(context)

    def execute(self, context):
        success = AutoCleanupController.restore(context)
        self.report({"INFO"} if success else {"WARNING"}, context.window_manager.boneweaver_runtime.quick_summary)
        return {"FINISHED"} if success else {"CANCELLED"}


AUTO_CLEANUP_OPERATOR_CLASSES = (
    BONEWEAVER_OT_auto_cleanup,
    BONEWEAVER_OT_restore_auto_cleanup,
)
